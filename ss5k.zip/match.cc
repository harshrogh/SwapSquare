#include "match.h"

int Match::maxRow = 10;
int Match::maxCol = 10;
